# -*- coding: utf-8 -*-
import numpy as np
import scipy.io as sio

u = sio.loadmat('Accel_Data')
z = sio.loadmat('Vel_Data')
u = np.array(u['a'])
z = np.array(z['v'])

def kf_predict(F,G,V,u,mu_1,sigma_1,Q_val = 0.1):
    Q = Q_val * np.eye(len(V))
    mu_bar = F*mu_1 + G*u
    sigma_bar = F*sigma_1*np.transpose(F) + V*Q*np.transpose(V)
    return(mu_bar, sigma_bar)

def kf_update(sigma_bar,mu_bar,z,C,R_val=0.1):
    R = R_val*np.eye(len(z))
    K = sigma_bar*C*(C*sigma_bar*np.transpose(C)+R)**-1
    mu = mu_bar + K*(z-C*mu_bar)
    sigma = sigma_bar-K*C*sigma_bar
    return (mu, sigma)

m = 1000
b = 50

F = np.array([1+.1*(-50/1000)])
G = np.array([.1*(1/1000)])
C = np.array([1])
V = np.array([.8])
mu_1 = 0
sigma_1 = 0

mu = np.array([[]])
sigma = np.array([[]])

for i in range(len(u)-1):

    mu_bar, sigma_bar = kf_predict(F, G, V, u[i], mu_1, sigma_1,0.5)
    mu_1, sigma_1 = kf_update(sigma_bar, mu_bar, z[i], C)
    print('mu = ', mu_1)
    mu = np.hstack((mu, mu_1))
    sigma = np.hstack((sigma, sigma_1))

print('sigma =', sigma)
print('mu = ', mu)